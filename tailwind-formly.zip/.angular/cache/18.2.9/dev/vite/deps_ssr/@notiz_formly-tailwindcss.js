import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  RouterLink
} from "./chunk-44T5DK7O.js";
import {
  FieldType,
  FieldWrapper,
  FormlyAttributes,
  FormlyModule,
  FormlyValidationMessage
} from "./chunk-S3BEU4J6.js";
import {
  CheckboxControlValueAccessor,
  CheckboxRequiredValidator,
  DefaultValueAccessor,
  FormControlDirective,
  NG_VALUE_ACCESSOR,
  NgControlStatus,
  NgSelectOption,
  NumberValueAccessor,
  RangeValueAccessor,
  ReactiveFormsModule,
  RequiredValidator,
  SelectControlValueAccessor,
  SelectMultipleControlValueAccessor,
  Validators,
  ɵNgSelectMultipleOption
} from "./chunk-N6QZJG7K.js";
import "./chunk-R5SPQIU7.js";
import {
  AsyncPipe,
  NgClass,
  NgForOf,
  NgIf,
  NgTemplateOutlet
} from "./chunk-5EZGT7ZD.js";
import {
  Component,
  Directive,
  HostBinding,
  NgModule,
  Pipe,
  require_cjs,
  require_operators,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵProvidersFeature,
  ɵɵStandaloneFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵdefineComponent,
  ɵɵdefineDirective,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdefinePipe,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵpureFunction3,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeHtml,
  ɵɵsanitizeUrl,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate1
} from "./chunk-TW4XVQZD.js";
import {
  __toESM
} from "./chunk-NQ4HTGF6.js";

// node_modules/@ngx-formly/core/fesm2015/ngx-formly-core-select.mjs
var import_rxjs = __toESM(require_cjs(), 1);
var import_operators = __toESM(require_operators(), 1);
var FormlySelectOptionsPipe = class {
  transform(options, field) {
    if (!(options instanceof import_rxjs.Observable)) {
      options = this.observableOf(options, field);
    } else {
      this.dispose();
    }
    return options.pipe((0, import_operators.map)((value) => this.transformOptions(value, field)));
  }
  ngOnDestroy() {
    this.dispose();
  }
  transformOptions(options, field) {
    const to = this.transformSelectProps(field);
    const opts = [];
    const groups = {};
    options === null || options === void 0 ? void 0 : options.forEach((option) => {
      const o = this.transformOption(option, to);
      if (o.group) {
        const id = groups[o.label];
        if (id === void 0) {
          groups[o.label] = opts.push(o) - 1;
        } else {
          o.group.forEach((o2) => opts[id].group.push(o2));
        }
      } else {
        opts.push(o);
      }
    });
    return opts;
  }
  transformOption(option, props) {
    const group = props.groupProp(option);
    if (Array.isArray(group)) {
      return {
        label: props.labelProp(option),
        group: group.map((opt) => this.transformOption(opt, props))
      };
    }
    option = {
      label: props.labelProp(option),
      value: props.valueProp(option),
      disabled: !!props.disabledProp(option)
    };
    if (group) {
      return {
        label: group,
        group: [option]
      };
    }
    return option;
  }
  transformSelectProps(field) {
    const props = (field === null || field === void 0 ? void 0 : field.props) || (field === null || field === void 0 ? void 0 : field.templateOptions) || {};
    const selectPropFn = (prop) => typeof prop === "function" ? prop : (o) => o[prop];
    return {
      groupProp: selectPropFn(props.groupProp || "group"),
      labelProp: selectPropFn(props.labelProp || "label"),
      valueProp: selectPropFn(props.valueProp || "value"),
      disabledProp: selectPropFn(props.disabledProp || "disabled")
    };
  }
  dispose() {
    if (this._options) {
      this._options.complete();
      this._options = null;
    }
    if (this._subscription) {
      this._subscription.unsubscribe();
      this._subscription = null;
    }
  }
  observableOf(options, f) {
    this.dispose();
    if (f && f.options && f.options.fieldChanges) {
      this._subscription = f.options.fieldChanges.pipe((0, import_operators.filter)(({
        property,
        type,
        field
      }) => {
        return type === "expressionChanges" && (property.indexOf("templateOptions.options") === 0 || property.indexOf("props.options") === 0) && field === f && Array.isArray(field.props.options) && !!this._options;
      }), (0, import_operators.tap)(() => this._options.next(f.props.options))).subscribe();
    }
    this._options = new import_rxjs.BehaviorSubject(options);
    return this._options.asObservable();
  }
};
FormlySelectOptionsPipe.ɵfac = function FormlySelectOptionsPipe_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || FormlySelectOptionsPipe)();
};
FormlySelectOptionsPipe.ɵpipe = ɵɵdefinePipe({
  name: "formlySelectOptions",
  type: FormlySelectOptionsPipe,
  pure: true
});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlySelectOptionsPipe, [{
    type: Pipe,
    args: [{
      name: "formlySelectOptions"
    }]
  }], null, null);
})();
var FormlySelectModule = class {
};
FormlySelectModule.ɵfac = function FormlySelectModule_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || FormlySelectModule)();
};
FormlySelectModule.ɵmod = ɵɵdefineNgModule({
  type: FormlySelectModule,
  declarations: [FormlySelectOptionsPipe],
  exports: [FormlySelectOptionsPipe]
});
FormlySelectModule.ɵinj = ɵɵdefineInjector({});
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlySelectModule, [{
    type: NgModule,
    args: [{
      declarations: [FormlySelectOptionsPipe],
      exports: [FormlySelectOptionsPipe]
    }]
  }], null, null);
})();

// node_modules/@notiz/formly-tailwindcss/fesm2022/notiz-formly-tailwindcss.mjs
var _c0 = (a0) => ({
  content: a0
});
var _c1 = (a0) => ({
  field: a0
});
function FormlyTailwindButton_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0, 4);
  }
  if (rf & 2) {
    const content_r2 = ctx.ngIf;
    ɵɵnextContext();
    const stringOrTemplate_r3 = ɵɵreference(3);
    ɵɵproperty("ngTemplateOutlet", stringOrTemplate_r3)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c0, content_r2));
  }
}
function FormlyTailwindButton_ng_template_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const content_r4 = ɵɵnextContext().content;
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", content_r4, " ");
  }
}
function FormlyTailwindButton_ng_template_2_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0, 4);
  }
  if (rf & 2) {
    const content_r4 = ɵɵnextContext().content;
    const ctx_r4 = ɵɵnextContext();
    ɵɵproperty("ngTemplateOutlet", content_r4)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c1, ctx_r4.props));
  }
}
function FormlyTailwindButton_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FormlyTailwindButton_ng_template_2_ng_container_0_Template, 2, 1, "ng-container", 5)(1, FormlyTailwindButton_ng_template_2_ng_template_1_Template, 1, 4, "ng-template", null, 1, ɵɵtemplateRefExtractor);
  }
  if (rf & 2) {
    const content_r4 = ctx.content;
    const template_r6 = ɵɵreference(2);
    ɵɵproperty("ngIf", !content_r4.createEmbeddedView)("ngIfElse", template_r6);
  }
}
var _c2 = (a0) => ({
  "cursor-not-allowed": a0
});
function FormlyTailwindCheckbox_span_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 4);
    ɵɵtext(1, " * ");
    ɵɵelementEnd();
  }
}
var _c3 = (a0) => [a0];
var _c4 = (a0) => ({
  "form-disabled opacity-50": a0
});
function FormlyTailwindWrapperFormField_label_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 10);
    ɵɵtext(1, " * ");
    ɵɵelementEnd();
  }
}
function FormlyTailwindWrapperFormField_label_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "label", 7);
    ɵɵelement(1, "div", 8);
    ɵɵtemplate(2, FormlyTailwindWrapperFormField_label_1_span_2_Template, 2, 0, "span", 9);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("for", ctx_r0.id);
    ɵɵadvance();
    ɵɵproperty("innerHtml", ctx_r0.props.label, ɵɵsanitizeHtml);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.props.required && !ctx_r0.props.hideRequiredMarker);
  }
}
function FormlyTailwindWrapperFormField_div_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0, 14);
  }
  if (rf & 2) {
    const hint_r2 = ctx.ngIf;
    ɵɵnextContext(2);
    const stringOrTemplate_r3 = ɵɵreference(7);
    ɵɵproperty("ngTemplateOutlet", stringOrTemplate_r3)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c0, hint_r2));
  }
}
function FormlyTailwindWrapperFormField_div_4_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div");
  }
}
function FormlyTailwindWrapperFormField_div_4_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0, 14);
  }
  if (rf & 2) {
    const hintEnd_r4 = ctx.ngIf;
    ɵɵnextContext(2);
    const stringOrTemplate_r3 = ɵɵreference(7);
    ɵɵproperty("ngTemplateOutlet", stringOrTemplate_r3)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c0, hintEnd_r4));
  }
}
function FormlyTailwindWrapperFormField_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 11);
    ɵɵtemplate(1, FormlyTailwindWrapperFormField_div_4_ng_container_1_Template, 1, 4, "ng-container", 12)(2, FormlyTailwindWrapperFormField_div_4_div_2_Template, 1, 0, "div", 13)(3, FormlyTailwindWrapperFormField_div_4_ng_container_3_Template, 1, 4, "ng-container", 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.props.description || ctx_r0.props.hintStart);
    ɵɵadvance();
    ɵɵproperty("ngIf", !(ctx_r0.props.description || ctx_r0.props.hintStart) && ctx_r0.props.hintEnd);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.props.hintEnd);
  }
}
function FormlyTailwindWrapperFormField_div_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵelement(1, "formly-validation-message", 16);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("field", ctx_r0.field);
  }
}
function FormlyTailwindWrapperFormField_ng_template_6_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "span", 18);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const content_r5 = ɵɵnextContext().content;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", content_r5, " ");
  }
}
function FormlyTailwindWrapperFormField_ng_template_6_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function FormlyTailwindWrapperFormField_ng_template_6_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FormlyTailwindWrapperFormField_ng_template_6_ng_template_1_ng_container_0_Template, 1, 0, "ng-container", 19);
  }
  if (rf & 2) {
    const content_r5 = ɵɵnextContext().content;
    ɵɵproperty("ngTemplateOutlet", content_r5);
  }
}
function FormlyTailwindWrapperFormField_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FormlyTailwindWrapperFormField_ng_template_6_ng_container_0_Template, 3, 1, "ng-container", 17)(1, FormlyTailwindWrapperFormField_ng_template_6_ng_template_1_Template, 1, 1, "ng-template", null, 2, ɵɵtemplateRefExtractor);
  }
  if (rf & 2) {
    const content_r5 = ctx.content;
    const template_r6 = ɵɵreference(2);
    ɵɵproperty("ngIf", !content_r5.createEmbeddedView)("ngIfElse", template_r6);
  }
}
function FormlyTailwindInput_input_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "input", 2);
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵclassProp("cursor-not-allowed", ctx_r0.props.disabled);
    ɵɵproperty("id", ctx_r0.id)("name", ctx_r0.key)("type", ctx_r0.type)("readonly", ctx_r0.props.readonly)("required", ctx_r0.props.required ? ctx_r0.props.required : false)("formControl", ctx_r0.formControl)("formlyAttributes", ctx_r0.field)("tabIndex", ctx_r0.props.tabindex)("placeholder", ctx_r0.props.placeholder);
  }
}
function FormlyTailwindInput_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "input", 3);
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵclassProp("cursor-not-allowed", ctx_r0.props.disabled);
    ɵɵproperty("id", ctx_r0.id)("name", ctx_r0.key)("readonly", ctx_r0.props.readonly)("required", ctx_r0.props.required ? ctx_r0.props.required : false)("formControl", ctx_r0.formControl)("formlyAttributes", ctx_r0.field)("tabIndex", ctx_r0.props.tabindex)("placeholder", ctx_r0.props.placeholder);
  }
}
function FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_option_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "option", 7);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const option_r1 = ɵɵnextContext().$implicit;
    ɵɵproperty("ngValue", option_r1.value)("disabled", option_r1.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", option_r1.label, " ");
  }
}
function FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_ng_template_2_option_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "option", 7);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const child_r2 = ctx.$implicit;
    ɵɵclassProp("cursor-not-allowed", child_r2.disabled);
    ɵɵproperty("ngValue", child_r2.value)("disabled", child_r2.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", child_r2.label, " ");
  }
}
function FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "optgroup", 8);
    ɵɵtemplate(1, FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_ng_template_2_option_1_Template, 2, 5, "option", 9);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const option_r1 = ɵɵnextContext().$implicit;
    ɵɵproperty("label", option_r1.label);
    ɵɵadvance();
    ɵɵproperty("ngForOf", option_r1.group);
  }
}
function FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_option_1_Template, 2, 3, "option", 6)(2, FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_ng_template_2_Template, 2, 2, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const option_r1 = ctx.$implicit;
    const optionGroup_r3 = ɵɵreference(3);
    ɵɵadvance();
    ɵɵproperty("ngIf", !option_r1.group)("ngIfElse", optionGroup_r3);
  }
}
function FormlyTailwindSelect_select_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FormlyTailwindSelect_select_0_ng_container_1_ng_container_1_Template, 4, 2, "ng-container", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const options_r4 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngForOf", options_r4);
  }
}
function FormlyTailwindSelect_select_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "select", 3);
    ɵɵtemplate(1, FormlyTailwindSelect_select_0_ng_container_1_Template, 2, 1, "ng-container", 4);
    ɵɵpipe(2, "formlySelectOptions");
    ɵɵpipe(3, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext();
    ɵɵclassProp("cursor-not-allowed", ctx_r4.props.disabled);
    ɵɵproperty("id", ctx_r4.id)("formControl", ctx_r4.formControl)("compareWith", ctx_r4.props.compareWith)("formlyAttributes", ctx_r4.field)("tabIndex", ctx_r4.props.tabindex)("required", ctx_r4.props.required ? ctx_r4.props.required : false);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(3, 12, ɵɵpipeBind2(2, 9, ctx_r4.props.options, ctx_r4.field)));
  }
}
function FormlyTailwindSelect_ng_template_1_option_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "option", 12);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵproperty("ngValue", void 0);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r4.props.placeholder, " ");
  }
}
function FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_option_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "option", 7);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const option_r6 = ɵɵnextContext().$implicit;
    ɵɵproperty("ngValue", option_r6.value)("disabled", option_r6.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", option_r6.label, " ");
  }
}
function FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_ng_template_2_option_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "option", 7);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const child_r7 = ctx.$implicit;
    ɵɵclassProp("cursor-not-allowed", child_r7.disabled);
    ɵɵproperty("ngValue", child_r7.value)("disabled", child_r7.disabled);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", child_r7.label, " ");
  }
}
function FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "optgroup", 8);
    ɵɵtemplate(1, FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_ng_template_2_option_1_Template, 2, 5, "option", 9);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const option_r6 = ɵɵnextContext().$implicit;
    ɵɵproperty("label", option_r6.label);
    ɵɵadvance();
    ɵɵproperty("ngForOf", option_r6.group);
  }
}
function FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_option_1_Template, 2, 3, "option", 6)(2, FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_ng_template_2_Template, 2, 2, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const option_r6 = ctx.$implicit;
    const optionGroup_r8 = ɵɵreference(3);
    ɵɵadvance();
    ɵɵproperty("ngIf", !option_r6.group)("ngIfElse", optionGroup_r8);
  }
}
function FormlyTailwindSelect_ng_template_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FormlyTailwindSelect_ng_template_1_ng_container_2_ng_container_1_Template, 4, 2, "ng-container", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const options_r9 = ctx.ngIf;
    ɵɵadvance();
    ɵɵproperty("ngForOf", options_r9);
  }
}
function FormlyTailwindSelect_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "select", 10);
    ɵɵtemplate(1, FormlyTailwindSelect_ng_template_1_option_1_Template, 2, 2, "option", 11)(2, FormlyTailwindSelect_ng_template_1_ng_container_2_Template, 2, 1, "ng-container", 4);
    ɵɵpipe(3, "formlySelectOptions");
    ɵɵpipe(4, "async");
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext();
    ɵɵclassProp("cursor-not-allowed", ctx_r4.props.disabled);
    ɵɵproperty("id", ctx_r4.id)("formControl", ctx_r4.formControl)("compareWith", ctx_r4.props.compareWith)("formlyAttributes", ctx_r4.field)("tabIndex", ctx_r4.props.tabindex)("required", ctx_r4.props.required ? ctx_r4.props.required : false);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r4.props.placeholder);
    ɵɵadvance();
    ɵɵproperty("ngIf", ɵɵpipeBind1(4, 13, ɵɵpipeBind2(3, 10, ctx_r4.props.options, ctx_r4.field)));
  }
}
var _c5 = (a0) => ({
  "cursor-not-allowed opacity-50": a0
});
function FormlyTailwindLink_a_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 2);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("href", ctx_r0.props.link, ɵɵsanitizeUrl)("target", ctx_r0.props.target)("rel", ctx_r0.props.rel)("ngClass", ɵɵpureFunction1(5, _c5, ctx_r0.props.disabled));
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r0.props.text, " ");
  }
}
function FormlyTailwindLink_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "a", 3);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("routerLink", ctx_r0.props.link)("ngClass", ɵɵpureFunction1(3, _c5, ctx_r0.props.disabled));
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", ctx_r0.props.text, " ");
  }
}
var _c6 = (a0, a1, a2) => ({
  "form-radio-disabled": a0,
  "cursor-not-allowed ": a1,
  "opacity-50": a2
});
var _c7 = (a0) => ({
  "cursor-not-allowed ": a0
});
function FormlyTailwindRadio_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 1)(1, "input", 2);
    ɵɵlistener("change", function FormlyTailwindRadio_div_0_Template_input_change_1_listener() {
      const option_r2 = ɵɵrestoreView(_r1).$implicit;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onChange(option_r2.value));
    });
    ɵɵelementEnd();
    ɵɵelementStart(2, "label", 3);
    ɵɵtext(3);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const option_r2 = ctx.$implicit;
    const i_r4 = ctx.index;
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction3(10, _c6, option_r2.disabled, option_r2.disabled || ctx_r2.props.disabled, option_r2.disabled && !ctx_r2.props.disabled));
    ɵɵadvance();
    ɵɵproperty("ngClass", ɵɵpureFunction1(14, _c7, option_r2.disabled || ctx_r2.props.disabled))("id", ctx_r2.id + "_" + i_r4)("name", ctx_r2.field.name || ctx_r2.id)("value", option_r2.value)("disabled", option_r2.disabled || ctx_r2.props.disabled ? true : false)("checked", (ctx_r2.formControl.value || ctx_r2.field.defaultValue) === option_r2.value);
    ɵɵadvance();
    ɵɵproperty("ngClass", ɵɵpureFunction1(16, _c7, option_r2.disabled || ctx_r2.props.disabled))("for", ctx_r2.id + "_" + i_r4);
    ɵɵadvance();
    ɵɵtextInterpolate1(" ", option_r2.label, " ");
  }
}
var FormlyTailwindButton = class _FormlyTailwindButton extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block mt-4";
    this.defaultOptions = {
      props: {
        type: "button"
        // button, submit, reset
      }
    };
  }
  onClick(event) {
    if (this.props.onClick) {
      this.props.onClick(event);
    }
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindButton_BaseFactory;
      return function FormlyTailwindButton_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindButton_BaseFactory || (ɵFormlyTailwindButton_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindButton)))(__ngFactoryType__ || _FormlyTailwindButton);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindButton,
      selectors: [["formly-button"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindButton_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 4,
      vars: 6,
      consts: [["stringOrTemplate", ""], ["template", ""], [1, "form-button", "w-full", 3, "click", "type", "ngClass", "disabled"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [4, "ngIf", "ngIfElse"]],
      template: function FormlyTailwindButton_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "button", 2);
          ɵɵlistener("click", function FormlyTailwindButton_Template_button_click_0_listener($event) {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.onClick($event));
          });
          ɵɵtemplate(1, FormlyTailwindButton_ng_container_1_Template, 1, 4, "ng-container", 3);
          ɵɵelementEnd();
          ɵɵtemplate(2, FormlyTailwindButton_ng_template_2_Template, 3, 2, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          ɵɵclassProp("form-button-disabled", ctx.props.disabled);
          ɵɵproperty("type", ctx.props.type)("ngClass", "form-button-" + ctx.props.style)("disabled", ctx.props.type === "submit" ? ctx.form.invalid || ctx.props.disabled : ctx.props.disabled);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.props.template || ctx.props.text);
        }
      },
      dependencies: [NgClass, NgIf, NgTemplateOutlet],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindButton, [{
    type: Component,
    args: [{
      selector: "formly-button",
      template: `
    <button
      class="form-button w-full"
      [type]="props.type"
      [ngClass]="'form-button-' + props.style"
      [class.form-button-disabled]="props.disabled"
      (click)="onClick($event)"
      [disabled]="
        props.type === 'submit'
          ? form.invalid || props.disabled
          : props.disabled
      "
    >
      <ng-container
        *ngIf="props.template || props.text as content"
        [ngTemplateOutlet]="stringOrTemplate"
        [ngTemplateOutletContext]="{ content: content }"
      >
      </ng-container>
    </button>

    <ng-template #stringOrTemplate let-content="content">
      <ng-container *ngIf="!content.createEmbeddedView; else template">
        {{ content }}
      </ng-container>
      <ng-template #template>
        <ng-container
          [ngTemplateOutlet]="content"
          [ngTemplateOutletContext]="{ field: props }"
        ></ng-container>
      </ng-template>
    </ng-template>
  `,
      standalone: true,
      imports: [NgClass, NgIf, NgTemplateOutlet]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindButtonModule = class _FormlyTailwindButtonModule {
  static {
    this.ɵfac = function FormlyTailwindButtonModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindButtonModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindButtonModule,
      imports: [FormlyModule, FormlyTailwindButton],
      exports: [FormlyTailwindButton]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "button",
          component: FormlyTailwindButton
        }]
      })]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindButtonModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "button",
          component: FormlyTailwindButton
        }]
      }), FormlyTailwindButton],
      exports: [FormlyTailwindButton]
    }]
  }], null, null);
})();
var FormlyTailwindCheckbox = class _FormlyTailwindCheckbox extends FieldType {
  constructor() {
    super(...arguments);
    this.defaultOptions = {
      props: {
        indeterminate: true,
        hideLabel: true
      }
    };
  }
  get class() {
    return `flex items-center ${this.props.disabled ? "cursor-not-allowed" : ""}`;
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindCheckbox_BaseFactory;
      return function FormlyTailwindCheckbox_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindCheckbox_BaseFactory || (ɵFormlyTailwindCheckbox_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindCheckbox)))(__ngFactoryType__ || _FormlyTailwindCheckbox);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindCheckbox,
      selectors: [["formly-checkbox"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindCheckbox_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 4,
      vars: 19,
      consts: [["type", "checkbox", 1, "form-checkbox", 3, "ngClass", "id", "name", "readonly", "disabled", "required", "formControl", "formlyAttributes", "indeterminate", "tabIndex"], [1, "form-checkbox-label", "ml-2", "flex", "items-center", "text-gray-700", 3, "for", "ngClass"], [3, "innerHtml"], ["class", "form-required text-red-700", 4, "ngIf"], [1, "form-required", "text-red-700"]],
      template: function FormlyTailwindCheckbox_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "input", 0);
          ɵɵelementStart(1, "label", 1);
          ɵɵelement(2, "div", 2);
          ɵɵtemplate(3, FormlyTailwindCheckbox_span_3_Template, 2, 0, "span", 3);
          ɵɵelementEnd();
        }
        if (rf & 2) {
          ɵɵproperty("ngClass", ɵɵpureFunction1(15, _c2, ctx.props.disabled))("id", ctx.id)("name", ctx.key)("readonly", ctx.props.readonly)("disabled", ctx.props.disabled ? ctx.props.disabled : false)("required", ctx.props.required ? ctx.props.required : false)("formControl", ctx.formControl)("formlyAttributes", ctx.field)("indeterminate", ctx.props.indeterminate && ctx.formControl.value == null)("tabIndex", ctx.props.tabindex);
          ɵɵattribute("aria-describedby", ctx.key);
          ɵɵadvance();
          ɵɵproperty("for", ctx.id)("ngClass", ɵɵpureFunction1(17, _c2, ctx.props.disabled));
          ɵɵadvance();
          ɵɵproperty("innerHtml", ctx.props.label, ɵɵsanitizeHtml);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.props.required && !ctx.props.hideRequiredMarker);
        }
      },
      dependencies: [NgClass, ReactiveFormsModule, CheckboxControlValueAccessor, NgControlStatus, CheckboxRequiredValidator, FormControlDirective, FormlyModule, FormlyAttributes, NgIf],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindCheckbox, [{
    type: Component,
    args: [{
      selector: "formly-checkbox",
      template: `
    <input
      class="form-checkbox"
      [ngClass]="{ 'cursor-not-allowed': props.disabled }"
      type="checkbox"
      [id]="id"
      [name]="key"
      [readonly]="props.readonly"
      [disabled]="props.disabled ? props.disabled : false"
      [required]="props.required ? props.required : false"
      [formControl]="formControl"
      [formlyAttributes]="field"
      [indeterminate]="props.indeterminate && formControl.value == null"
      [tabIndex]="props.tabindex"
      [attr.aria-describedby]="key"
    />

    <label
      [for]="id"
      class="form-checkbox-label  ml-2 flex items-center text-gray-700"
      [ngClass]="{ 'cursor-not-allowed': props.disabled }"
    >
      <!-- TODO same label as the wrapper -->
      <div [innerHtml]="props.label"></div>
      <!-- TODO is this needed when the wrapper is applied? -->
      <span
        *ngIf="props.required && !props.hideRequiredMarker"
        class="form-required text-red-700"
      >
        *
      </span>
    </label>
  `,
      standalone: true,
      imports: [NgClass, ReactiveFormsModule, FormlyModule, NgIf]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindCheckboxModule = class _FormlyTailwindCheckboxModule {
  static {
    this.ɵfac = function FormlyTailwindCheckboxModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindCheckboxModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindCheckboxModule,
      imports: [FormlyModule, FormlyTailwindCheckbox],
      exports: [FormlyTailwindCheckbox]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "checkbox",
          component: FormlyTailwindCheckbox,
          wrappers: ["form-field"]
        }, {
          name: "boolean",
          extends: "checkbox"
        }]
      }), FormlyTailwindCheckbox]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindCheckboxModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "checkbox",
          component: FormlyTailwindCheckbox,
          wrappers: ["form-field"]
        }, {
          name: "boolean",
          extends: "checkbox"
        }]
      }), FormlyTailwindCheckbox],
      exports: [FormlyTailwindCheckbox]
    }]
  }], null, null);
})();
var FormlyTailwindDatepicker = class _FormlyTailwindDatepicker extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block";
    this.supportedDateTypes = ["date", "datetime-local", "month", "week", "time"];
  }
  get type() {
    if (this.props.type !== void 0) {
      const supportedType = this.supportedDateTypes.some((types) => types === this.props.type);
      if (!supportedType) {
        console.warn(`Datepicker doesn't support ${this.props.type} fallback to 'date'.`);
      }
      return supportedType ? this.props.type : "date";
    }
    return "date";
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindDatepicker_BaseFactory;
      return function FormlyTailwindDatepicker_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindDatepicker_BaseFactory || (ɵFormlyTailwindDatepicker_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindDatepicker)))(__ngFactoryType__ || _FormlyTailwindDatepicker);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindDatepicker,
      selectors: [["formly-datepicker"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindDatepicker_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 1,
      vars: 11,
      consts: [[1, "form-input", "w-full", 3, "type", "id", "name", "readonly", "required", "formControl", "formlyAttributes", "tabIndex", "placeholder"]],
      template: function FormlyTailwindDatepicker_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "input", 0);
        }
        if (rf & 2) {
          ɵɵclassProp("cursor-not-allowed", ctx.props.disabled);
          ɵɵproperty("type", ctx.type)("id", ctx.id)("name", ctx.key)("readonly", ctx.props.readonly)("required", ctx.props.required ? ctx.props.required : false)("formControl", ctx.formControl)("formlyAttributes", ctx.field)("tabIndex", ctx.props.tabindex)("placeholder", ctx.props.placeholder);
        }
      },
      dependencies: [ReactiveFormsModule, DefaultValueAccessor, NgControlStatus, RequiredValidator, FormControlDirective, FormlyModule, FormlyAttributes],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindDatepicker, [{
    type: Component,
    args: [{
      selector: "formly-datepicker",
      template: `
    <input
      class="form-input w-full"
      [class.cursor-not-allowed]="props.disabled"
      [type]="type"
      [id]="id"
      [name]="key"
      [readonly]="props.readonly"
      [required]="props.required ? props.required : false"
      [formControl]="formControl"
      [formlyAttributes]="field"
      [tabIndex]="props.tabindex"
      [placeholder]="props.placeholder"
    />
  `,
      standalone: true,
      imports: [ReactiveFormsModule, FormlyModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindDatepickerModule = class _FormlyTailwindDatepickerModule {
  static {
    this.ɵfac = function FormlyTailwindDatepickerModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindDatepickerModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindDatepickerModule,
      imports: [FormlyModule, FormlyTailwindDatepicker],
      exports: [FormlyTailwindDatepicker]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "datepicker",
          component: FormlyTailwindDatepicker,
          wrappers: ["form-field"]
        }, {
          name: "date",
          extends: "datepicker"
        }, {
          name: "datetime-local",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "datetime-local"
            }
          }
        }, {
          name: "month",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "month"
            }
          }
        }, {
          name: "week",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "week"
            }
          }
        }, {
          name: "time",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "time"
            }
          }
        }]
      }), FormlyTailwindDatepicker]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindDatepickerModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "datepicker",
          component: FormlyTailwindDatepicker,
          wrappers: ["form-field"]
        }, {
          name: "date",
          extends: "datepicker"
        }, {
          name: "datetime-local",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "datetime-local"
            }
          }
        }, {
          name: "month",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "month"
            }
          }
        }, {
          name: "week",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "week"
            }
          }
        }, {
          name: "time",
          extends: "datepicker",
          defaultOptions: {
            props: {
              type: "time"
            }
          }
        }]
      }), FormlyTailwindDatepicker],
      exports: [FormlyTailwindDatepicker]
    }]
  }], null, null);
})();
var FormlyTailwindDivider = class _FormlyTailwindDivider extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block mt-4";
    this.defaultOptions = {
      props: {
        dividerClasses: "border-gray-300",
        textClasses: "bg-white text-sm text-red-500"
      }
    };
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindDivider_BaseFactory;
      return function FormlyTailwindDivider_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindDivider_BaseFactory || (ɵFormlyTailwindDivider_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindDivider)))(__ngFactoryType__ || _FormlyTailwindDivider);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindDivider,
      selectors: [["formly-divider"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindDivider_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 6,
      vars: 7,
      consts: [[1, "form-divider", "relative"], ["aria-hidden", "true", 1, "absolute", "inset-0", "flex", "items-center"], [1, "form-divider-border", "w-full", "border-t", 3, "ngClass"], [1, "relative", "flex", "justify-center"], [1, "form-divider-text", "px-2", 3, "ngClass"]],
      template: function FormlyTailwindDivider_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0)(1, "div", 1);
          ɵɵelement(2, "div", 2);
          ɵɵelementEnd();
          ɵɵelementStart(3, "div", 3)(4, "span", 4);
          ɵɵtext(5);
          ɵɵelementEnd()()();
        }
        if (rf & 2) {
          ɵɵadvance(2);
          ɵɵproperty("ngClass", ɵɵpureFunction1(3, _c3, ctx.props.dividerClasses));
          ɵɵadvance(2);
          ɵɵproperty("ngClass", ɵɵpureFunction1(5, _c3, ctx.props.textClasses));
          ɵɵadvance();
          ɵɵtextInterpolate1(" ", ctx.props.text, " ");
        }
      },
      dependencies: [NgClass],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindDivider, [{
    type: Component,
    args: [{
      selector: "formly-divider",
      template: `
    <div class="form-divider relative">
      <div class="absolute inset-0 flex items-center" aria-hidden="true">
        <div
          class="form-divider-border w-full border-t"
          [ngClass]="[props.dividerClasses]"
        ></div>
      </div>
      <div class="relative flex justify-center">
        <span class="form-divider-text px-2" [ngClass]="[props.textClasses]">
          {{ props.text }}
        </span>
      </div>
    </div>
  `,
      standalone: true,
      imports: [NgClass]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindDividerModule = class _FormlyTailwindDividerModule {
  static {
    this.ɵfac = function FormlyTailwindDividerModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindDividerModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindDividerModule,
      imports: [FormlyModule, FormlyTailwindDivider],
      exports: [FormlyTailwindDivider]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "divider",
          component: FormlyTailwindDivider
        }]
      })]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindDividerModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "divider",
          component: FormlyTailwindDivider
        }]
      }), FormlyTailwindDivider],
      exports: [FormlyTailwindDivider]
    }]
  }], null, null);
})();
var FileValueAccessor = class _FileValueAccessor {
  constructor() {
    this.onChange = (_) => {
    };
    this.onTouched = () => {
    };
  }
  writeValue(value) {
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  static {
    this.ɵfac = function FileValueAccessor_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FileValueAccessor)();
    };
  }
  static {
    this.ɵdir = ɵɵdefineDirective({
      type: _FileValueAccessor,
      selectors: [["input", "type", "file"]],
      hostBindings: function FileValueAccessor_HostBindings(rf, ctx) {
        if (rf & 1) {
          ɵɵlistener("change", function FileValueAccessor_change_HostBindingHandler($event) {
            return ctx.onChange($event.target.files);
          })("blur", function FileValueAccessor_blur_HostBindingHandler() {
            return ctx.onTouched();
          });
        }
      },
      standalone: true,
      features: [ɵɵProvidersFeature([{
        provide: NG_VALUE_ACCESSOR,
        useExisting: _FileValueAccessor,
        multi: true
      }])]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FileValueAccessor, [{
    type: Directive,
    args: [{
      selector: "input[type=file]",
      host: {
        "(change)": "onChange($event.target.files)",
        "(blur)": "onTouched()"
      },
      providers: [{
        provide: NG_VALUE_ACCESSOR,
        useExisting: FileValueAccessor,
        multi: true
      }],
      standalone: true
    }]
  }], null, null);
})();
var FormlyTailwindFile = class _FormlyTailwindFile extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block";
    this.defaultOptions = {
      props: {
        accept: [],
        multiple: false
      }
    };
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindFile_BaseFactory;
      return function FormlyTailwindFile_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindFile_BaseFactory || (ɵFormlyTailwindFile_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindFile)))(__ngFactoryType__ || _FormlyTailwindFile);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindFile,
      selectors: [["formly-file"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindFile_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 1,
      vars: 5,
      consts: [["type", "file", 1, "form-file", "w-full", 3, "id", "formControl", "formlyAttributes", "accept", "multiple"]],
      template: function FormlyTailwindFile_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "input", 0);
        }
        if (rf & 2) {
          ɵɵproperty("id", ctx.id)("formControl", ctx.formControl)("formlyAttributes", ctx.field)("accept", ctx.props.accept)("multiple", ctx.props.multiple);
        }
      },
      dependencies: [FileValueAccessor, ReactiveFormsModule, DefaultValueAccessor, NgControlStatus, FormControlDirective, FormlyModule, FormlyAttributes],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindFile, [{
    type: Component,
    args: [{
      selector: "formly-file",
      template: `
    <!-- TODO use file variant in tailwindcss@3.x.x to style the input -->
    <input
      class="form-file w-full"
      type="file"
      [id]="id"
      [formControl]="formControl"
      [formlyAttributes]="field"
      [accept]="props.accept"
      [multiple]="props.multiple"
    />
  `,
      standalone: true,
      imports: [FileValueAccessor, ReactiveFormsModule, FormlyModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindFileModule = class _FormlyTailwindFileModule {
  static {
    this.ɵfac = function FormlyTailwindFileModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindFileModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindFileModule,
      imports: [FormlyModule, FormlyTailwindFile],
      exports: [FormlyTailwindFile]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "file",
          component: FormlyTailwindFile,
          wrappers: ["form-field"]
        }]
      }), FormlyTailwindFile]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindFileModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "file",
          component: FormlyTailwindFile,
          wrappers: ["form-field"]
        }]
      }), FormlyTailwindFile],
      exports: [FormlyTailwindFile],
      providers: []
    }]
  }], null, null);
})();
var FormlyTailwindWrapperFormField = class _FormlyTailwindWrapperFormField extends FieldWrapper {
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindWrapperFormField_BaseFactory;
      return function FormlyTailwindWrapperFormField_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindWrapperFormField_BaseFactory || (ɵFormlyTailwindWrapperFormField_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindWrapperFormField)))(__ngFactoryType__ || _FormlyTailwindWrapperFormField);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindWrapperFormField,
      selectors: [["formly-field"]],
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 8,
      vars: 10,
      consts: [["fieldComponent", ""], ["stringOrTemplate", ""], ["template", ""], [1, "mt-4", "block", 3, "ngClass"], ["class", "form-label mb-0.5 inline-flex text-gray-700", 3, "for", 4, "ngIf"], ["class", "form-hint mt-0.5 flex justify-between", 4, "ngIf"], ["class", "form-error-message mt-0.5 text-sm text-red-400", 4, "ngIf"], [1, "form-label", "mb-0.5", "inline-flex", "text-gray-700", 3, "for"], [3, "innerHtml"], ["class", "form-required text-red-700", 4, "ngIf"], [1, "form-required", "text-red-700"], [1, "form-hint", "mt-0.5", "flex", "justify-between"], [3, "ngTemplateOutlet", "ngTemplateOutletContext", 4, "ngIf"], [4, "ngIf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "form-error-message", "mt-0.5", "text-sm", "text-red-400"], [3, "field"], [4, "ngIf", "ngIfElse"], [1, "form-hint-text", "text-sm", "text-gray-600"], [4, "ngTemplateOutlet"]],
      template: function FormlyTailwindWrapperFormField_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 3);
          ɵɵtemplate(1, FormlyTailwindWrapperFormField_label_1_Template, 3, 3, "label", 4);
          ɵɵelementContainer(2, null, 0);
          ɵɵtemplate(4, FormlyTailwindWrapperFormField_div_4_Template, 4, 3, "div", 5)(5, FormlyTailwindWrapperFormField_div_5_Template, 2, 1, "div", 6);
          ɵɵelementEnd();
          ɵɵtemplate(6, FormlyTailwindWrapperFormField_ng_template_6_Template, 3, 2, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          ɵɵclassProp("form-error", ctx.showError)("form-disabled", ctx.props.disabled);
          ɵɵproperty("ngClass", ɵɵpureFunction1(8, _c4, ctx.props.disabled));
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.props.label && !ctx.props.hideLabel);
          ɵɵadvance(3);
          ɵɵproperty("ngIf", (ctx.props.description || ctx.props.hintStart || ctx.props.hintEnd) && !ctx.showError);
          ɵɵadvance();
          ɵɵproperty("ngIf", ctx.showError);
        }
      },
      dependencies: [NgClass, NgIf, NgTemplateOutlet, FormlyModule, FormlyValidationMessage],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindWrapperFormField, [{
    type: Component,
    args: [{
      selector: "formly-field",
      template: `
    <div
      class="mt-4 block"
      [class.form-error]="showError"
      [class.form-disabled]="props.disabled"
      [ngClass]="{
        'form-disabled opacity-50': props.disabled
      }"
    >
      <label
        *ngIf="props.label && !props.hideLabel"
        class="form-label mb-0.5 inline-flex text-gray-700"
        [for]="id"
      >
        <div [innerHtml]="props.label"></div>
        <span
          *ngIf="props.required && !props.hideRequiredMarker"
          class="form-required text-red-700"
        >
          *
        </span>
      </label>
      <ng-container #fieldComponent></ng-container>
      <div
        *ngIf="
          (props.description || props.hintStart || props.hintEnd) && !showError
        "
        class="form-hint mt-0.5 flex justify-between"
      >
        <ng-container
          *ngIf="props.description || props.hintStart as hint"
          [ngTemplateOutlet]="stringOrTemplate"
          [ngTemplateOutletContext]="{ content: hint }"
        >
        </ng-container>
        <!-- divider if hintStart is empty to position hintEnd correctly -->
        <div
          *ngIf="!(props.description || props.hintStart) && props.hintEnd"
        ></div>
        <ng-container
          *ngIf="props.hintEnd as hintEnd"
          [ngTemplateOutlet]="stringOrTemplate"
          [ngTemplateOutletContext]="{ content: hintEnd }"
        >
        </ng-container>
      </div>

      <div
        *ngIf="showError"
        class="form-error-message mt-0.5 text-sm text-red-400"
      >
        <formly-validation-message [field]="field"></formly-validation-message>
      </div>
    </div>

    <ng-template #stringOrTemplate let-content="content">
      <ng-container *ngIf="!content.createEmbeddedView; else template">
        <span class="form-hint-text text-sm text-gray-600">
          {{ content }}
        </span>
      </ng-container>
      <ng-template #template>
        <ng-container *ngTemplateOutlet="content"></ng-container>
      </ng-template>
    </ng-template>
  `,
      standalone: true,
      imports: [NgClass, NgIf, NgTemplateOutlet, FormlyModule]
    }]
  }], null, null);
})();
var FormlyTailwindFormFieldModule = class _FormlyTailwindFormFieldModule {
  static {
    this.ɵfac = function FormlyTailwindFormFieldModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindFormFieldModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindFormFieldModule,
      imports: [FormlyModule, FormlyTailwindWrapperFormField],
      exports: [FormlyTailwindWrapperFormField]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        wrappers: [{
          name: "form-field",
          component: FormlyTailwindWrapperFormField
        }]
      }), FormlyTailwindWrapperFormField]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindFormFieldModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        wrappers: [{
          name: "form-field",
          component: FormlyTailwindWrapperFormField
        }]
      }), FormlyTailwindWrapperFormField],
      exports: [FormlyTailwindWrapperFormField]
    }]
  }], null, null);
})();
var FormlyTailwindInput = class _FormlyTailwindInput extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block";
  }
  get type() {
    return this.props.type || "text";
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindInput_BaseFactory;
      return function FormlyTailwindInput_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindInput_BaseFactory || (ɵFormlyTailwindInput_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindInput)))(__ngFactoryType__ || _FormlyTailwindInput);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindInput,
      selectors: [["formly-input"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindInput_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 3,
      vars: 2,
      consts: [["numberInput", ""], ["class", "form-input w-full", 3, "cursor-not-allowed", "id", "name", "type", "readonly", "required", "formControl", "formlyAttributes", "tabIndex", "placeholder", 4, "ngIf", "ngIfElse"], [1, "form-input", "w-full", 3, "id", "name", "type", "readonly", "required", "formControl", "formlyAttributes", "tabIndex", "placeholder"], ["type", "number", 1, "form-input", "w-full", 3, "id", "name", "readonly", "required", "formControl", "formlyAttributes", "tabIndex", "placeholder"]],
      template: function FormlyTailwindInput_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, FormlyTailwindInput_input_0_Template, 1, 11, "input", 1)(1, FormlyTailwindInput_ng_template_1_Template, 1, 10, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const numberInput_r2 = ɵɵreference(2);
          ɵɵproperty("ngIf", ctx.type !== "number")("ngIfElse", numberInput_r2);
        }
      },
      dependencies: [NgIf, ReactiveFormsModule, DefaultValueAccessor, NumberValueAccessor, NgControlStatus, RequiredValidator, FormControlDirective, FormlyModule, FormlyAttributes],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindInput, [{
    type: Component,
    args: [{
      selector: "formly-input",
      template: `
    <input
      *ngIf="type !== 'number'; else numberInput"
      class="form-input w-full"
      [class.cursor-not-allowed]="props.disabled"
      [id]="id"
      [name]="key"
      [type]="type"
      [readonly]="props.readonly"
      [required]="props.required ? props.required : false"
      [formControl]="formControl"
      [formlyAttributes]="field"
      [tabIndex]="props.tabindex"
      [placeholder]="props.placeholder"
    />

    <ng-template #numberInput>
      <input
        type="number"
        class="form-input w-full"
        [class.cursor-not-allowed]="props.disabled"
        [id]="id"
        [name]="key"
        [readonly]="props.readonly"
        [required]="props.required ? props.required : false"
        [formControl]="formControl"
        [formlyAttributes]="field"
        [tabIndex]="props.tabindex"
        [placeholder]="props.placeholder"
      />
    </ng-template>
  `,
      standalone: true,
      imports: [NgIf, ReactiveFormsModule, FormlyModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindInputModule = class _FormlyTailwindInputModule {
  static {
    this.ɵfac = function FormlyTailwindInputModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindInputModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindInputModule,
      imports: [FormlyModule, FormlyTailwindInput],
      exports: [FormlyTailwindInput]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "input",
          component: FormlyTailwindInput,
          wrappers: ["form-field"]
        }, {
          name: "string",
          extends: "input"
        }, {
          name: "text",
          extends: "input"
        }, {
          name: "email",
          extends: "input",
          defaultOptions: {
            props: {
              type: "email"
            }
          }
        }, {
          name: "password",
          extends: "input",
          defaultOptions: {
            props: {
              type: "password"
            }
          }
        }, {
          name: "number",
          extends: "input",
          defaultOptions: {
            props: {
              type: "number"
            }
          }
        }]
      }), FormlyTailwindInput]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindInputModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "input",
          component: FormlyTailwindInput,
          wrappers: ["form-field"]
        }, {
          name: "string",
          extends: "input"
        }, {
          name: "text",
          extends: "input"
        }, {
          name: "email",
          extends: "input",
          defaultOptions: {
            props: {
              type: "email"
            }
          }
        }, {
          name: "password",
          extends: "input",
          defaultOptions: {
            props: {
              type: "password"
            }
          }
        }, {
          name: "number",
          extends: "input",
          defaultOptions: {
            props: {
              type: "number"
            }
          }
        }]
      }), FormlyTailwindInput],
      exports: [FormlyTailwindInput]
    }]
  }], null, null);
})();
var FormlyTailwindTextarea = class _FormlyTailwindTextarea extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block";
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindTextarea_BaseFactory;
      return function FormlyTailwindTextarea_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindTextarea_BaseFactory || (ɵFormlyTailwindTextarea_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindTextarea)))(__ngFactoryType__ || _FormlyTailwindTextarea);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindTextarea,
      selectors: [["formly-textarea"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindTextarea_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 1,
      vars: 9,
      consts: [[1, "form-textarea", "w-full", 3, "id", "cols", "rows", "required", "formControl", "formlyAttributes", "tabIndex"]],
      template: function FormlyTailwindTextarea_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "textarea", 0);
        }
        if (rf & 2) {
          ɵɵclassProp("cursor-not-allowed", ctx.props.disabled);
          ɵɵproperty("id", ctx.id)("cols", ctx.props.cols)("rows", ctx.props.rows)("required", ctx.props.required ? ctx.props.required : false)("formControl", ctx.formControl)("formlyAttributes", ctx.field)("tabIndex", ctx.props.tabindex);
        }
      },
      dependencies: [ReactiveFormsModule, DefaultValueAccessor, NgControlStatus, RequiredValidator, FormControlDirective, FormlyModule, FormlyAttributes],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindTextarea, [{
    type: Component,
    args: [{
      selector: "formly-textarea",
      template: `
    <textarea
      class="form-textarea w-full"
      [class.cursor-not-allowed]="props.disabled"
      [id]="id"
      [cols]="props.cols"
      [rows]="props.rows"
      [required]="props.required ? props.required : false"
      [formControl]="formControl"
      [formlyAttributes]="field"
      [tabIndex]="props.tabindex"
    ></textarea>
  `,
      standalone: true,
      imports: [ReactiveFormsModule, FormlyModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindTextareaModule = class _FormlyTailwindTextareaModule {
  static {
    this.ɵfac = function FormlyTailwindTextareaModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindTextareaModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindTextareaModule,
      imports: [FormlyModule, FormlyTailwindTextarea],
      exports: [FormlyTailwindTextarea]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "textarea",
          component: FormlyTailwindTextarea,
          wrappers: ["form-field"]
        }]
      }), FormlyTailwindTextarea]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindTextareaModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "textarea",
          component: FormlyTailwindTextarea,
          wrappers: ["form-field"]
        }]
      }), FormlyTailwindTextarea],
      exports: [FormlyTailwindTextarea]
    }]
  }], null, null);
})();
var FormlyTailwindSelect = class _FormlyTailwindSelect extends FieldType {
  constructor() {
    super(...arguments);
    this.defaultOptions = {
      props: {
        options: [],
        compareWith(o1, o2) {
          return o1 === o2;
        }
      }
    };
    this.class = "block";
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindSelect_BaseFactory;
      return function FormlyTailwindSelect_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindSelect_BaseFactory || (ɵFormlyTailwindSelect_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindSelect)))(__ngFactoryType__ || _FormlyTailwindSelect);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindSelect,
      selectors: [["formly-select"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindSelect_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 3,
      vars: 2,
      consts: [["singleSelect", ""], ["optionGroup", ""], ["class", "form-multiselect w-full", "multiple", "", 3, "cursor-not-allowed", "id", "formControl", "compareWith", "formlyAttributes", "tabIndex", "required", 4, "ngIf", "ngIfElse"], ["multiple", "", 1, "form-multiselect", "w-full", 3, "id", "formControl", "compareWith", "formlyAttributes", "tabIndex", "required"], [4, "ngIf"], [4, "ngFor", "ngForOf"], [3, "ngValue", "disabled", 4, "ngIf", "ngIfElse"], [3, "ngValue", "disabled"], [3, "label"], [3, "cursor-not-allowed", "ngValue", "disabled", 4, "ngFor", "ngForOf"], [1, "form-select", "w-full", 3, "id", "formControl", "compareWith", "formlyAttributes", "tabIndex", "required"], [3, "ngValue", 4, "ngIf"], [3, "ngValue"]],
      template: function FormlyTailwindSelect_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, FormlyTailwindSelect_select_0_Template, 4, 14, "select", 2)(1, FormlyTailwindSelect_ng_template_1_Template, 5, 15, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const singleSelect_r10 = ɵɵreference(2);
          ɵɵproperty("ngIf", ctx.props.multiple)("ngIfElse", singleSelect_r10);
        }
      },
      dependencies: [NgIf, NgForOf, AsyncPipe, ReactiveFormsModule, NgSelectOption, ɵNgSelectMultipleOption, SelectControlValueAccessor, SelectMultipleControlValueAccessor, NgControlStatus, RequiredValidator, FormControlDirective, FormlyModule, FormlyAttributes, FormlySelectModule, FormlySelectOptionsPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindSelect, [{
    type: Component,
    args: [{
      selector: "formly-select",
      template: `
    <select
      *ngIf="props.multiple; else singleSelect"
      class="form-multiselect w-full"
      [class.cursor-not-allowed]="props.disabled"
      [id]="id"
      [formControl]="formControl"
      [compareWith]="props.compareWith"
      [formlyAttributes]="field"
      [tabIndex]="props.tabindex"
      [required]="props.required ? props.required : false"
      multiple
    >
      <ng-container
        *ngIf="props.options | formlySelectOptions : field | async as options"
      >
        <ng-container *ngFor="let option of options">
          <option
            *ngIf="!option.group; else optionGroup"
            [ngValue]="option.value"
            [disabled]="option.disabled"
          >
            {{ option.label }}
          </option>
          <ng-template #optionGroup>
            <optgroup [label]="option.label">
              <option
                *ngFor="let child of option.group"
                [class.cursor-not-allowed]="child.disabled"
                [ngValue]="child.value"
                [disabled]="child.disabled"
              >
                {{ child.label }}
              </option>
            </optgroup>
          </ng-template>
        </ng-container>
      </ng-container>
    </select>

    <ng-template #singleSelect>
      <select
        class="form-select w-full"
        [class.cursor-not-allowed]="props.disabled"
        [id]="id"
        [formControl]="formControl"
        [compareWith]="props.compareWith"
        [formlyAttributes]="field"
        [tabIndex]="props.tabindex"
        [required]="props.required ? props.required : false"
      >
        <option *ngIf="props.placeholder" [ngValue]="undefined">
          {{ props.placeholder }}
        </option>
        <ng-container
          *ngIf="props.options | formlySelectOptions : field | async as options"
        >
          <ng-container *ngFor="let option of options">
            <option
              *ngIf="!option.group; else optionGroup"
              [ngValue]="option.value"
              [disabled]="option.disabled"
            >
              {{ option.label }}
            </option>
            <ng-template #optionGroup>
              <optgroup [label]="option.label">
                <option
                  *ngFor="let child of option.group"
                  [class.cursor-not-allowed]="child.disabled"
                  [ngValue]="child.value"
                  [disabled]="child.disabled"
                >
                  {{ child.label }}
                </option>
              </optgroup>
            </ng-template>
          </ng-container>
        </ng-container>
      </select>
    </ng-template>
  `,
      standalone: true,
      imports: [NgIf, NgForOf, AsyncPipe, ReactiveFormsModule, FormlyModule, FormlySelectModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindSelectModule = class _FormlyTailwindSelectModule {
  static {
    this.ɵfac = function FormlyTailwindSelectModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindSelectModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindSelectModule,
      imports: [FormlyModule, FormlyTailwindSelect],
      exports: [FormlyTailwindSelect]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "select",
          component: FormlyTailwindSelect,
          wrappers: ["form-field"]
        }, {
          name: "enum",
          extends: "select"
        }]
      }), FormlyTailwindSelect]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindSelectModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "select",
          component: FormlyTailwindSelect,
          wrappers: ["form-field"]
        }, {
          name: "enum",
          extends: "select"
        }]
      }), FormlyTailwindSelect],
      exports: [FormlyTailwindSelect]
    }]
  }], null, null);
})();
var LinkTarget;
(function(LinkTarget2) {
  LinkTarget2["nothing"] = "";
  LinkTarget2["blank"] = "_blank";
  LinkTarget2["self"] = "_self";
  LinkTarget2["parent"] = "_parent";
})(LinkTarget || (LinkTarget = {}));
var LinkRel;
(function(LinkRel2) {
  LinkRel2["noOpener"] = "noopener";
  LinkRel2["noReferrer"] = "noreferrer";
})(LinkRel || (LinkRel = {}));
var FormlyTailwindLink = class _FormlyTailwindLink extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block";
    this.defaultOptions = {
      props: {
        target: LinkTarget.nothing,
        rel: LinkRel.noOpener
      }
    };
  }
  get isExternalLink() {
    return /^(https?.*|mailto|tel).*/.test(this.props.link);
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindLink_BaseFactory;
      return function FormlyTailwindLink_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindLink_BaseFactory || (ɵFormlyTailwindLink_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindLink)))(__ngFactoryType__ || _FormlyTailwindLink);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindLink,
      selectors: [["formly-link"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindLink_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 3,
      vars: 2,
      consts: [["internalLink", ""], ["class", "form-link", 3, "href", "target", "rel", "ngClass", 4, "ngIf", "ngIfElse"], [1, "form-link", 3, "href", "target", "rel", "ngClass"], [1, "form-link", 3, "routerLink", "ngClass"]],
      template: function FormlyTailwindLink_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, FormlyTailwindLink_a_0_Template, 2, 7, "a", 1)(1, FormlyTailwindLink_ng_template_1_Template, 2, 5, "ng-template", null, 0, ɵɵtemplateRefExtractor);
        }
        if (rf & 2) {
          const internalLink_r2 = ɵɵreference(2);
          ɵɵproperty("ngIf", ctx.isExternalLink)("ngIfElse", internalLink_r2);
        }
      },
      dependencies: [NgIf, NgClass, RouterLink],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindLink, [{
    type: Component,
    args: [{
      selector: "formly-link",
      template: `
    <a
      *ngIf="isExternalLink; else internalLink"
      [href]="props.link"
      class="form-link"
      [target]="props.target"
      [rel]="props.rel"
      [ngClass]="{ 'cursor-not-allowed opacity-50': props.disabled }"
    >
      {{ props.text }}
    </a>

    <ng-template #internalLink>
      <a
        [routerLink]="props.link"
        class="form-link"
        [ngClass]="{ 'cursor-not-allowed opacity-50': props.disabled }"
      >
        {{ props.text }}
      </a>
    </ng-template>
  `,
      standalone: true,
      imports: [NgIf, NgClass, RouterLink]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindLinkModule = class _FormlyTailwindLinkModule {
  static {
    this.ɵfac = function FormlyTailwindLinkModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindLinkModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindLinkModule,
      imports: [FormlyModule, FormlyTailwindLink],
      exports: [FormlyTailwindLink]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "link",
          component: FormlyTailwindLink
        }]
      })]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindLinkModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "link",
          component: FormlyTailwindLink
        }]
      }), FormlyTailwindLink],
      exports: [FormlyTailwindLink]
    }]
  }], null, null);
})();
var RadioOrientation;
(function(RadioOrientation2) {
  RadioOrientation2["col"] = "col";
  RadioOrientation2["row"] = "row";
})(RadioOrientation || (RadioOrientation = {}));
var FormlyTailwindRadio = class _FormlyTailwindRadio extends FieldType {
  constructor() {
    super(...arguments);
    this.defaultOptions = {
      props: {
        options: [],
        orientation: RadioOrientation.row
      }
    };
  }
  get class() {
    return `flex ${this.props.orientation === "col" ? "flex-col" : "flex-row"}`;
  }
  onChange(value) {
    this.formControl.setValue(value);
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindRadio_BaseFactory;
      return function FormlyTailwindRadio_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindRadio_BaseFactory || (ɵFormlyTailwindRadio_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindRadio)))(__ngFactoryType__ || _FormlyTailwindRadio);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindRadio,
      selectors: [["formly-radio"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindRadio_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 3,
      vars: 6,
      consts: [["class", "mr-2 inline-flex items-center", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "mr-2", "inline-flex", "items-center", 3, "ngClass"], ["type", "radio", 1, "form-radio", 3, "change", "ngClass", "id", "name", "value", "disabled", "checked"], [1, "form-radio-label", "ml-2", "text-gray-700", 3, "ngClass", "for"]],
      template: function FormlyTailwindRadio_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, FormlyTailwindRadio_div_0_Template, 4, 18, "div", 0);
          ɵɵpipe(1, "formlySelectOptions");
          ɵɵpipe(2, "async");
        }
        if (rf & 2) {
          ɵɵproperty("ngForOf", ɵɵpipeBind1(2, 4, ɵɵpipeBind2(1, 1, ctx.props.options, ctx.field)));
        }
      },
      dependencies: [NgForOf, NgClass, AsyncPipe, FormlySelectModule, FormlySelectOptionsPipe],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindRadio, [{
    type: Component,
    args: [{
      selector: "formly-radio",
      template: `
    <div
      *ngFor="
        let option of props.options | formlySelectOptions : field | async;
        let i = index
      "
      class="mr-2 inline-flex items-center"
      [ngClass]="{
        'form-radio-disabled': option.disabled,
        'cursor-not-allowed ': option.disabled || props.disabled,
        'opacity-50': option.disabled && !props.disabled
      }"
    >
      <input
        type="radio"
        class="form-radio"
        [ngClass]="{ 'cursor-not-allowed ': option.disabled || props.disabled }"
        [id]="id + '_' + i"
        [name]="field.name || id"
        [value]="option.value"
        [disabled]="option.disabled || props.disabled ? true : false"
        (change)="onChange(option.value)"
        [checked]="(formControl.value || field.defaultValue) === option.value"
      />
      <label
        class="form-radio-label ml-2 text-gray-700"
        [ngClass]="{ 'cursor-not-allowed ': option.disabled || props.disabled }"
        [for]="id + '_' + i"
      >
        {{ option.label }}
      </label>
    </div>
  `,
      standalone: true,
      imports: [NgForOf, NgClass, AsyncPipe, FormlySelectModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindRadioModule = class _FormlyTailwindRadioModule {
  static {
    this.ɵfac = function FormlyTailwindRadioModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindRadioModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindRadioModule,
      imports: [FormlyModule, FormlyTailwindRadio],
      exports: [FormlyTailwindRadio]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "radio",
          component: FormlyTailwindRadio,
          wrappers: ["form-field"]
        }]
      }), FormlyTailwindRadio]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindRadioModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "radio",
          component: FormlyTailwindRadio,
          wrappers: ["form-field"]
        }]
      }), FormlyTailwindRadio],
      exports: [FormlyTailwindRadio]
    }]
  }], null, null);
})();
var FormlyTailwindRange = class _FormlyTailwindRange extends FieldType {
  constructor() {
    super(...arguments);
    this.defaultOptions = {
      props: {
        min: 0,
        max: 100,
        step: 1
      }
    };
    this.class = "block";
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindRange_BaseFactory;
      return function FormlyTailwindRange_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindRange_BaseFactory || (ɵFormlyTailwindRange_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindRange)))(__ngFactoryType__ || _FormlyTailwindRange);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindRange,
      selectors: [["formly-range"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindRange_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 1,
      vars: 11,
      consts: [["type", "range", 1, "form-range", "w-full", 3, "id", "name", "readonly", "required", "formControl", "formlyAttributes", "min", "max", "step"]],
      template: function FormlyTailwindRange_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "input", 0);
        }
        if (rf & 2) {
          ɵɵclassProp("cursor-not-allowed", ctx.props.disabled);
          ɵɵproperty("id", ctx.id)("name", ctx.key)("readonly", ctx.props.readonly)("required", ctx.props.required ? ctx.props.required : false)("formControl", ctx.formControl)("formlyAttributes", ctx.field)("min", ctx.props.min)("max", ctx.props.max)("step", ctx.props.step);
        }
      },
      dependencies: [ReactiveFormsModule, DefaultValueAccessor, RangeValueAccessor, NgControlStatus, RequiredValidator, FormControlDirective, FormlyModule, FormlyAttributes],
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindRange, [{
    type: Component,
    args: [{
      selector: "formly-range",
      template: `
    <input
      class="form-range w-full"
      [class.cursor-not-allowed]="props.disabled"
      type="range"
      [id]="id"
      [name]="key"
      [readonly]="props.readonly"
      [required]="props.required ? props.required : false"
      [formControl]="formControl"
      [formlyAttributes]="field"
      [min]="props.min"
      [max]="props.max"
      [step]="props.step"
    />
  `,
      standalone: true,
      imports: [ReactiveFormsModule, FormlyModule]
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindRangeModule = class _FormlyTailwindRangeModule {
  static {
    this.ɵfac = function FormlyTailwindRangeModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindRangeModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindRangeModule,
      imports: [FormlyModule, FormlyTailwindRange],
      exports: [FormlyTailwindRange]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "range",
          component: FormlyTailwindRange,
          wrappers: ["form-field"]
        }, {
          name: "slider",
          extends: "range"
        }]
      }), FormlyTailwindRange]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindRangeModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "range",
          component: FormlyTailwindRange,
          wrappers: ["form-field"]
        }, {
          name: "slider",
          extends: "range"
        }]
      }), FormlyTailwindRange],
      exports: [FormlyTailwindRange]
    }]
  }], null, null);
})();
var FormlyTailwindTypography = class _FormlyTailwindTypography extends FieldType {
  constructor() {
    super(...arguments);
    this.class = "block";
    this.defaultOptions = {
      className: "prose"
    };
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵFormlyTailwindTypography_BaseFactory;
      return function FormlyTailwindTypography_Factory(__ngFactoryType__) {
        return (ɵFormlyTailwindTypography_BaseFactory || (ɵFormlyTailwindTypography_BaseFactory = ɵɵgetInheritedFactory(_FormlyTailwindTypography)))(__ngFactoryType__ || _FormlyTailwindTypography);
      };
    })();
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _FormlyTailwindTypography,
      selectors: [["formly-typography"]],
      hostVars: 2,
      hostBindings: function FormlyTailwindTypography_HostBindings(rf, ctx) {
        if (rf & 2) {
          ɵɵclassMap(ctx.class);
        }
      },
      standalone: true,
      features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
      decls: 1,
      vars: 1,
      consts: [[1, "form-typography", 3, "innerHTML"]],
      template: function FormlyTailwindTypography_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
        }
        if (rf & 2) {
          ɵɵproperty("innerHTML", ctx.props.content, ɵɵsanitizeHtml);
        }
      },
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindTypography, [{
    type: Component,
    args: [{
      selector: "formly-typography",
      template: `<div class="form-typography" [innerHTML]="props.content"></div> `,
      standalone: true
    }]
  }], null, {
    class: [{
      type: HostBinding,
      args: ["class"]
    }]
  });
})();
var FormlyTailwindTypographyModule = class _FormlyTailwindTypographyModule {
  static {
    this.ɵfac = function FormlyTailwindTypographyModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindTypographyModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindTypographyModule,
      imports: [FormlyModule, FormlyTailwindTypography],
      exports: [FormlyTailwindTypography]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyModule.forChild({
        types: [{
          name: "typography",
          component: FormlyTailwindTypography
        }, {
          name: "content",
          extends: "typography"
        }]
      })]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindTypographyModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyModule.forChild({
        types: [{
          name: "typography",
          component: FormlyTailwindTypography
        }, {
          name: "content",
          extends: "typography"
        }]
      }), FormlyTailwindTypography],
      exports: [FormlyTailwindTypography]
    }]
  }], null, null);
})();
var FormlyTailwindcssModule = class _FormlyTailwindcssModule {
  static {
    this.ɵfac = function FormlyTailwindcssModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FormlyTailwindcssModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _FormlyTailwindcssModule,
      imports: [FormlyTailwindButtonModule, FormlyTailwindCheckboxModule, FormlyTailwindDatepickerModule, FormlyTailwindDividerModule, FormlyTailwindFormFieldModule, FormlyTailwindInputModule, FormlyTailwindLinkModule, FormlyTailwindRadioModule, FormlyTailwindRangeModule, FormlyTailwindSelectModule, FormlyTailwindTextareaModule, FormlyTailwindFileModule, FormlyTailwindTypographyModule]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [FormlyTailwindButtonModule, FormlyTailwindCheckboxModule, FormlyTailwindDatepickerModule, FormlyTailwindDividerModule, FormlyTailwindFormFieldModule, FormlyTailwindInputModule, FormlyTailwindLinkModule, FormlyTailwindRadioModule, FormlyTailwindRangeModule, FormlyTailwindSelectModule, FormlyTailwindTextareaModule, FormlyTailwindFileModule, FormlyTailwindTypographyModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormlyTailwindcssModule, [{
    type: NgModule,
    args: [{
      imports: [FormlyTailwindButtonModule, FormlyTailwindCheckboxModule, FormlyTailwindDatepickerModule, FormlyTailwindDividerModule, FormlyTailwindFormFieldModule, FormlyTailwindInputModule, FormlyTailwindLinkModule, FormlyTailwindRadioModule, FormlyTailwindRangeModule, FormlyTailwindSelectModule, FormlyTailwindTextareaModule, FormlyTailwindFileModule, FormlyTailwindTypographyModule]
    }]
  }], null, null);
})();
var validators = [{
  name: "required",
  validation: Validators.required
}, {
  name: "requiredTrue",
  validation: Validators.requiredTrue
}, {
  name: "email",
  validation: Validators.email
}, {
  name: "minLength",
  validation: (control, field) => {
    return Validators.minLength(field.props?.minLength || 0);
  }
}, {
  name: "maxLength",
  validation: (control, field) => {
    return Validators.maxLength(field.props?.maxLength || 0);
  }
}, {
  name: "min",
  validation: (control, field) => {
    return Validators.min(field.props?.min || 0);
  }
}, {
  name: "max",
  validation: (control, field) => {
    return Validators.min(field.props?.max || 0);
  }
}];
var validationMessages = [{
  name: "required",
  message: "Is required."
}, {
  name: "requiredTrue",
  message: "Must be checked."
}, {
  name: "email",
  message: "Is not a valid email."
}, {
  name: "minLength",
  message: (error, field) => {
    return `Must be at least ${field.props?.minLength} characters long.`;
  }
}, {
  name: "maxLength",
  message: (error, field) => {
    return `Must be shorter than ${field.props?.maxLength} characters.`;
  }
}, {
  name: "min",
  message: (error, field) => {
    return `Must be a number bigger than ${field.props?.min}.`;
  }
}, {
  name: "max",
  message: (error, field) => {
    return `Must be a number smaller than ${field.props?.max}.`;
  }
}];
export {
  FormlyTailwindButton,
  FormlyTailwindButtonModule,
  FormlyTailwindCheckbox,
  FormlyTailwindCheckboxModule,
  FormlyTailwindDatepicker,
  FormlyTailwindDatepickerModule,
  FormlyTailwindDivider,
  FormlyTailwindDividerModule,
  FormlyTailwindFile,
  FormlyTailwindFileModule,
  FormlyTailwindFormFieldModule,
  FormlyTailwindInput,
  FormlyTailwindInputModule,
  FormlyTailwindLink,
  FormlyTailwindLinkModule,
  FormlyTailwindRadio,
  FormlyTailwindRadioModule,
  FormlyTailwindRange,
  FormlyTailwindRangeModule,
  FormlyTailwindSelect,
  FormlyTailwindSelectModule,
  FormlyTailwindTextarea,
  FormlyTailwindTextareaModule,
  FormlyTailwindTypography,
  FormlyTailwindTypographyModule,
  FormlyTailwindWrapperFormField,
  FormlyTailwindcssModule,
  LinkRel,
  LinkTarget,
  RadioOrientation,
  validationMessages,
  validators
};
//# sourceMappingURL=@notiz_formly-tailwindcss.js.map
