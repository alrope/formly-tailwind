import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  FORMLY_CONFIG,
  FieldArrayType,
  FieldType,
  FieldWrapper,
  FormlyAttributes,
  FormlyConfig,
  FormlyField,
  FormlyForm,
  FormlyFormBuilder,
  FormlyGroup,
  FormlyModule,
  FormlyTemplate,
  FormlyValidationMessage,
  clone,
  defineHiddenProp,
  getFieldValue,
  hasKey,
  observe,
  reverseDeepMerge
} from "./chunk-S3BEU4J6.js";
import "./chunk-N6QZJG7K.js";
import "./chunk-R5SPQIU7.js";
import "./chunk-5EZGT7ZD.js";
import "./chunk-TW4XVQZD.js";
import "./chunk-NQ4HTGF6.js";
export {
  FORMLY_CONFIG,
  FieldArrayType,
  FieldType,
  FieldWrapper,
  FormlyConfig,
  FormlyField,
  FormlyForm,
  FormlyFormBuilder,
  FormlyModule,
  FormlyAttributes as ɵFormlyAttributes,
  FormlyGroup as ɵFormlyGroup,
  FormlyTemplate as ɵFormlyTemplate,
  FormlyValidationMessage as ɵFormlyValidationMessage,
  clone as ɵclone,
  defineHiddenProp as ɵdefineHiddenProp,
  getFieldValue as ɵgetFieldValue,
  hasKey as ɵhasKey,
  observe as ɵobserve,
  reverseDeepMerge as ɵreverseDeepMerge
};
//# sourceMappingURL=@ngx-formly_core.js.map
